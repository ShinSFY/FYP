# -*- coding: utf-8 -*-
"""
Created on Wed May 10 14:23:12 2023

@author: sfy
"""

import os
import sys
pwd = os.path.dirname(os.path.abspath(__file__))
sys.path.append(pwd)
print('pwd:',pwd)


class Hyperparamters:
    # Train parameters
    num_train_epochs = 100
    print_step = 250 #每隔多少步打印一次训练信息
    batch_size = 64 #每次训练用64个样本。    
    batch_size_eval = 128 #验证时的批次大小
    summary_step = 250  #每隔多少步记录一次训练摘要
    num_saved_per_epoch = 1  #每个epoch保存的模型数量
    max_to_keep = 300
    logdir = 'logdir/model_01' #存储日志和摘要的目录路径
    file_save_model = 'model/model_01'
    file_load_model = 'model/model_01'
    
    warmup_proportion = 0.1    
    use_tpu = None
    do_lower_case = True    #是否将所有文本转为小写。这里设置为True，表示将所有文本转为小写。
    learning_rate = 5e-5     
    num_filters = 128    
    filter_sizes = [2,3,4]
    embedding_size = 384
    keep_prob = 0.5

    # Sequence and Label
    sequence_length = 140
    num_labels = 9
    dict_label = {
    '0': '0',
    '1': '1',
    '2': '2',
    '3': '3',
    '4': '4',
    '5': '5',
    '6': '6',
    '7': '7',
    '8': '8'}
    '''
    dict_label = {
    'normal': '0',
    'caution': '1',
    'Depression': '2',
    'Anxiety': '3',
    'BipolarDisorder': '4',
    'PTSD': '5',
    'PanicDiorder': '6',
    'EatingDisorder': '7',
    'Other': '8'}
    '''
    
    # ALBERT parameters
    name = 'albert_small_zh_google'
    bert_path = os.path.join(pwd,name)
    data_dir = os.path.join(pwd,'data')
    vocab_file = os.path.join(pwd,name,'vocab_chinese.txt')  
    init_checkpoint = os.path.join(pwd,name,'albert_model.ckpt')
    saved_model_path = os.path.join(pwd,'model')    
    
    
    
    
    
    
    
    


    
    
